
/**
 * 模型层
 * 数据实体类
 */
export default class MyData {
    public Level: number = 0;
    
    
}
