# Cocos creator + PureMvc
cocos creator 版本 2.0.9

一个简单的PureMvcDemo

# MVCS 各层对应的类
1. 模型层 -> 在PureMvc中对应 Proxy
    模型层包含 数据实体类 和 数据代理类
    对应 MyData类 和 DataProxy

2. 视图层 在PureMvc中对应 Mediator 
    DataMediator

3. 控制层 -> 在PureMvc中对应 Command
    DataCommand类

4. Facade层
    ApplicationFacade



